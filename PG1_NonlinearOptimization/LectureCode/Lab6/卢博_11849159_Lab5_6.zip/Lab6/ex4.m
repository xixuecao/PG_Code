clear;clc
N = [3 5 10 20];
fun4(N)