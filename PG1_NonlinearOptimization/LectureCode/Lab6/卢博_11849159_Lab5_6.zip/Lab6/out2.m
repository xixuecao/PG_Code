function [c,ceq] = out2(x)
c =  norm(x) - 1;
ceq = [];
end

