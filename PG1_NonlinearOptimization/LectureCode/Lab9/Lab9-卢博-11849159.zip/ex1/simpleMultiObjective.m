function y = simpleMultiObjective(x)
y(1) = (x+2).^2 - 10;
y(2) = (x-2).^2 + 20;
end

