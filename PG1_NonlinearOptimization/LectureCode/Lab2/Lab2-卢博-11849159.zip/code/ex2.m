clear;clc;
paraboloid([-0.5, -0.5]')

