clear;clc;
v1 = [-2, 2]';
v2 = [2, 1]';
[e,a] = orthonormal(v1,v2)
