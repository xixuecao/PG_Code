clear;clc
data = {[0,0],[2,-1],[2.8,5],[4,2],[5,-1],[6,5],[7,8]};
Polynomial_Interpolation(data)